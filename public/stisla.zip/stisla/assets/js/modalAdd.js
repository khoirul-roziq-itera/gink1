        $('#toggle-modal-1').fireModal({
          title: 'My Modal',
          body: 'Hello, dude!',
          buttons: [
            {
              text: 'Close',
              class: 'btn btn-secondary',
              handler: function(current_modal) {
              $.destroyModal(current_modal);
              }
            }
          ]
        });

 